---
name: Thumbnail request
about: Request a new thumbnail
title: "[Thumbnail]"
labels: enhancement, thumbnail
assignees: flocke, RichyHBM, ziegenberg

---

<!-- Please fill in **all the information below** to help speed up the process! -->

**Name**:
**Website**:
**Link to SVG or EPS image**:
